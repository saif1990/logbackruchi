package com.ruchi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StartWebApplication {

	public static void main(String[] args) {
		System.setProperty("spring.config.location", "C:\\Users\\xbbkcnp\\Downloads\\spring-boot-master (1)\\spring-boot-master\\application.properties");
		SpringApplication.run(StartWebApplication.class, args);
	}

}